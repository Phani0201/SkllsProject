export class Customer {
    id: number;
    firstname: string;
    lastname: string;
    location: string;
    email:string;
}
