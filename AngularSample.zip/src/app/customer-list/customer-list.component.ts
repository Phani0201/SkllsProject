import { Component, OnInit } from '@angular/core';

import {FormControl,FormGroup,Validators} from '@angular/forms';  
import { Subject } from 'rxjs';
import { Customer } from '../customer';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {

 


  customers: Customer[]=[];
  responseData: any;
  filteredCustomers: any;
  //games: Customer[] = [];
  _listFilter='';
  

  
  get listFilter(): string {
    return this._listFilter;
}
  set listFilter(value: string) {
    this._listFilter = value;
    this.filteredCustomers = this.listFilter ? this.doFilter(this.listFilter) : this.responseData;

}


doFilter(filterBy: string): Customer[] {
  filterBy = filterBy.toLocaleLowerCase();
  return this.responseData.filter((game: Customer) =>
      game.location.toLocaleLowerCase().indexOf(filterBy) !== -1);
}
  
  ngOnInit(): void {
    this.retrieveAllCustomers();
    
  }
  retrieveAllCustomers()
  {
    this.customerService.getStudentList().subscribe((res: any)=>{
      this.responseData = JSON.parse(JSON.stringify(res))["customers"];
      this.filteredCustomers=JSON.parse(JSON.stringify(res))["customers"];
    },
    err => {
      console.log(err);
    },
    () => {
      console.log(this.responseData);
     }
    );
  }

  constructor(private customerService:CustomerService) {
  
    this.filteredCustomers=this.responseData;
    this.listFilter='';
   
   }

}
