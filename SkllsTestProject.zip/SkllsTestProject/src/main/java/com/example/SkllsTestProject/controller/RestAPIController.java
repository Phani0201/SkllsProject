package com.example.SkllsTestProject.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.SkllsTestProject.model.CustomerModel;
import com.example.SkllsTestProject.model.Message;
import com.example.SkllsTestProject.service.CustomerServices;

@CrossOrigin(origins = "http://localhost:4200")	//for bypassing CORSFilter
@RestController
@RequestMapping("/api/customer")
public class RestAPIController {
	
	@Autowired
	CustomerServices customerServices;
	
	@PostMapping("/create")
	public ResponseEntity<Message> addNewCustomer(@RequestBody CustomerModel customer) {
		try {
			CustomerModel returnedCustomer = customerServices.saveCustomer(customer);
			
			return new ResponseEntity<Message>(new Message("Upload Successfully!", 
											Arrays.asList(returnedCustomer), ""), HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<Message>(new Message("Fail to post a new Customer!", 
											null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);			
		}
	}
	
	@GetMapping("/retrieveinfos")
	public ResponseEntity<Message> retrieveCustomerInfo() {
		
		try {
			List<CustomerModel> customerInfos = customerServices.getCustomerInfos();
			
			return new ResponseEntity<Message>(new Message("Get Customers' Infos!", 
												customerInfos, ""), HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<Message>(new Message("Fail!",
												null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
}