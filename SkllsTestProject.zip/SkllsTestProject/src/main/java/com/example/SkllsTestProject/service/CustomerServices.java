package com.example.SkllsTestProject.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SkllsTestProject.model.CustomerModel;
import com.example.SkllsTestProject.repository.CustomerRepository;




@Service
public class CustomerServices {
	
	@Autowired CustomerRepository repository;
	
	public CustomerModel saveCustomer(CustomerModel customer) {
		return repository.save(customer);
	}
	
	public List<CustomerModel> getCustomerInfos(){
		return repository.findAll();
	}
	
	
}