package com.example.SkllsTestProject.model;

import java.util.ArrayList;
import java.util.List;

public class Message {
	private String message = "";
	private List<CustomerModel> customers = new ArrayList<CustomerModel>();
	private String error = "";
	
	public Message(String message, List<CustomerModel> customers, String error) {
		this.message = message;
		this.customers = customers;
		this.error = error;
	}
	
	public String getMessage() {
		return this.message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public List<CustomerModel> getCustomers(){
		return this.customers;
	}
	
	public void setCustomers(ArrayList<CustomerModel> customers) {
		this.customers = customers;
	}
	
	public void setError(String error) {
		this.error = error;
	}
	
	public String getError() {
		return this.error;
	}
}