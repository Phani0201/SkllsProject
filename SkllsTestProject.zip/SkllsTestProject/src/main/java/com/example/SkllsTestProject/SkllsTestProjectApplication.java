package com.example.SkllsTestProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkllsTestProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkllsTestProjectApplication.class, args);
	}

}
